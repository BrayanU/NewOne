/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serversocket;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.*;

/**
 *
 * @author buseche
 */
public class ServerSocke {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnknownHostException, IOException {
        InetAddress ipAddress = null;
        ipAddress = InetAddress.getByName("localhost");
        int port = 3000, backlog = 0;

        ServerSocket servidor = new ServerSocket(port, backlog, ipAddress);
        System.out.println("Servidor inició " + servidor.getInetAddress() + ":" + servidor.getLocalPort());

        Socket cliente = servidor.accept();
        System.out.println("Cliente conectado");

        DataInputStream in = new DataInputStream(cliente.getInputStream());

        String mensaje = "";
        try {
            do {
                mensaje = in.readUTF();
                System.out.println("El cliente escribió " + mensaje);

            } while (!mensaje.equals("end"));
        } catch (Exception e) {

        } finally {
            cliente.close();
            servidor.close();

        }
        System.out.println("END!!!!!!!!!!!");
    }

}
