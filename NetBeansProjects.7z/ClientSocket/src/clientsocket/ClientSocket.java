/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientsocket;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 *
 * @author buseche
 */
public class ClientSocket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnknownHostException, IOException {
        InetAddress ip = InetAddress.getByName("localhost");
        int port = 3000;
        Socket cliente = new Socket(ip, port);
        System.out.println("Cliente conectado");
        BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
        String mensaje = "";
            do {
                System.out.println("Write end to end");
                mensaje = sc.readLine();
                out.writeUTF(mensaje);
            } while (!mensaje.equals("end"));
    }

}
